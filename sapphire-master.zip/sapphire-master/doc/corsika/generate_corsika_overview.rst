Create an overview of CORSIKA simulations
=========================================

.. automodule:: sapphire.corsika.generate_corsika_overview
   :members:
   :undoc-members:
