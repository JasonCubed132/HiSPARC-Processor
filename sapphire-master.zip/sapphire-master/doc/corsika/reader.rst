CORSIKA Reader
==============

.. automodule:: sapphire.corsika.reader
   :members:
   :undoc-members:
