Store CORSIKA data as HDF5
==========================

.. automodule:: sapphire.corsika.store_corsika_data
   :members:
   :undoc-members:
