CORSIKA on Stoomboot
====================

.. automodule:: sapphire.corsika.qsub_corsika
   :members:
   :undoc-members:
