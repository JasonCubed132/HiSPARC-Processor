Test installation
=================

.. automodule:: sapphire.tests
   :members:
   :undoc-members:
