def square(x):
    return x ** 2


if __name__ == '__main__':
    print(1, 2, 3)
    print(square(1), square(2), square(3))
