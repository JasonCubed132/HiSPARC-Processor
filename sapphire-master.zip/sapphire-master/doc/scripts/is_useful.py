def square(x):
    return x ** 2

print(1, 2, 3)
print(square(1), square(2), square(3))
