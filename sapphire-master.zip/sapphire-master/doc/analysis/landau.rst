Landau distribution
===================

.. automodule:: sapphire.analysis.landau
   :members:
   :undoc-members:
