.. include:: ../subst.inc

Get signal and timing values from events
========================================

.. automodule:: sapphire.analysis.event_utils
   :members:
   :undoc-members:
