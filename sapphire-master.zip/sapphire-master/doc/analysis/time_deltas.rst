Time deltas 
===========

.. automodule:: sapphire.analysis.time_deltas
   :members:
   :undoc-members:
