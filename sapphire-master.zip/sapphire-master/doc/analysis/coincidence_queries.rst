.. include:: ../subst.inc

Query coincidences from a datafile
==================================

.. automodule:: sapphire.analysis.coincidence_queries
   :members:
   :undoc-members:
