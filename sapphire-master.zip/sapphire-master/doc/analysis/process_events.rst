Processing of HiSPARC events
============================

.. automodule:: sapphire.analysis.process_events
   :members:
   :undoc-members:
