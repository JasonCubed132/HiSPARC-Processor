Processing of HiSPARC traces
============================

.. automodule:: sapphire.analysis.process_traces
   :members:
   :undoc-members:
