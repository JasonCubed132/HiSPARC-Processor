.. include:: ../subst.inc

Search for coincidences between |hisparc| stations
==================================================

.. automodule:: sapphire.analysis.coincidences
   :members:
   :undoc-members:
