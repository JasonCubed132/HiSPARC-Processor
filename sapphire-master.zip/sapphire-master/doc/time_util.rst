GPS date/time utility functions
===============================

.. automodule:: sapphire.time_util
   :members:
   :undoc-members:
