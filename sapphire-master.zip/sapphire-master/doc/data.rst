Updating and extending local data
=================================

.. automodule:: sapphire.data
   :members:
   :undoc-members:

.. toctree::
   :hidden:

   data/extend_local_data
   data/update_local_data
