Update default local data with latest data from Publicdb
========================================================

.. automodule:: sapphire.data.update_local_data
   :members:
   :undoc-members:
