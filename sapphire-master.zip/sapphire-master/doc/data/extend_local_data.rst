Download additional local data
==============================

.. automodule:: sapphire.data.extend_local_data
   :members:
   :undoc-members:
