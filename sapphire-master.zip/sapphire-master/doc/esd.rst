Event Summary Data
==================

.. automodule:: sapphire.esd
   :members:
   :undoc-members:
