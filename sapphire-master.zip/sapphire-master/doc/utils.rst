Common utility functions
========================

.. automodule:: sapphire.utils
   :members:
   :undoc-members:
