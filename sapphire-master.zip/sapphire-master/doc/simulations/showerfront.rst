Simulations based on time structure of EAS shower fronts
========================================================

.. automodule:: sapphire.simulations.showerfront
   :members:
   :undoc-members:
