Detector simulations
====================

.. automodule:: sapphire.simulations.detector
   :members:
   :undoc-members:
