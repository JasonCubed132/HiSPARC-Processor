Simulation of detector response due to gammas
====================================================================

.. automodule:: sapphire.simulations.gammas
   :members:
   :undoc-members:
